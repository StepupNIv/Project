# Complete DevOps Project: Static Website with Jenkins, Docker, Kubernetes & Monitoring

A production-ready DevOps practice project demonstrating the complete CI/CD pipeline with containerization, orchestration, and monitoring.

## 📋 Project Architecture

```
Developer → Git Push → Jenkins (CI/CD) → Docker Build → Docker Registry
                                               ↓
                                    Kubernetes Cluster
                                               ↓
                      Pod → Service → Ingress/LB
                                               ↓
                    Prometheus & Grafana Monitoring
```

## 🎯 Technologies Included

- **Web Application**: Static HTML/CSS/JS website
- **CI/CD**: Jenkins with declarative pipeline
- **Containerization**: Docker & Docker Compose
- **Orchestration**: Kubernetes (minikube for local, cloud-ready)
- **Monitoring**: Prometheus + Grafana
- **Database**: MySQL (optional, for practice)
- **Version Control**: Git

## 📁 Project Structure

```
devops-website-project/
├── app/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── script.js
│   └── img/
├── database/
│   └── init.sql
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
├── kubernetes/
│   ├── namespace.yaml
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── ingress.yaml
│   ├── configmap.yaml
│   └── mysql-deployment.yaml
├── monitoring/
│   ├── prometheus/
│   │   └── prometheus.yml
│   └── grafana/
│       └── dashboards/
├── .github/
│   └── workflows/
├── Jenkinsfile
├── .gitignore
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- Docker installed
- Kubernetes cluster (minikube/EKS/GKE/AKS)
- Jenkins server running
- Git configured
- kubectl configured
- Docker registry (Docker Hub/ECR/GCR)

### Step 1: Clone and Setup Repository

```bash
git clone https://github.com/yourusername/devops-website-project.git
cd devops-website-project

# Initialize git (if new repo)
git init
git add .
git commit -m "Initial commit: DevOps project setup"
git branch -M main
git remote add origin https://github.com/yourusername/devops-website-project.git
git push -u origin main
```

### Step 2: Build Docker Image Locally

```bash
docker build -t devops-website:1.0.0 -f docker/Dockerfile .
docker run -p 8080:80 devops-website:1.0.0
# Visit http://localhost:8080
```

### Step 3: Tag and Push to Registry

```bash
# For Docker Hub
docker tag devops-website:1.0.0 yourusername/devops-website:1.0.0
docker push yourusername/devops-website:1.0.0

# For AWS ECR
docker tag devops-website:1.0.0 YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/devops-website:1.0.0
docker push YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/devops-website:1.0.0
```

### Step 4: Setup Kubernetes Cluster

```bash
# Create namespace
kubectl apply -f kubernetes/namespace.yaml

# Create ConfigMap for app configuration
kubectl apply -f kubernetes/configmap.yaml

# Deploy MySQL database (optional)
kubectl apply -f kubernetes/mysql-deployment.yaml
kubectl wait --for=condition=ready pod -l app=mysql -n devops-app --timeout=300s

# Deploy application
kubectl apply -f kubernetes/deployment.yaml
kubectl apply -f kubernetes/service.yaml
kubectl apply -f kubernetes/ingress.yaml

# Verify deployment
kubectl get pods -n devops-app
kubectl get svc -n devops-app
```

### Step 5: Setup Jenkins Pipeline

#### 5.1 Install Required Jenkins Plugins

- Docker Pipeline
- Kubernetes Continuous Deploy
- Git
- Pipeline
- Blue Ocean (optional, for UI)

#### 5.2 Create Jenkins Job

```
1. New Item → Pipeline
2. Name: devops-website-pipeline
3. Pipeline script from SCM → Git
4. Repository URL: https://github.com/yourusername/devops-website-project.git
5. Branch: */main
6. Script Path: Jenkinsfile
7. Save and Build
```

#### 5.3 Configure Jenkins Credentials

```
Manage Jenkins → Credentials → System → Global credentials

Add the following:
- Docker Registry (Docker Hub)
  Username: your_dockerhub_username
  Password: your_dockerhub_token
  ID: docker-hub

- Kubernetes Config
  Upload kubeconfig file
  ID: kubeconfig

- GitHub (if private repo)
  Token: your_github_token
  ID: github-token
```

### Step 6: Setup Monitoring

#### 6.1 Deploy Prometheus

```bash
kubectl create configmap prometheus-config \
  --from-file=monitoring/prometheus/prometheus.yml \
  -n devops-app

kubectl apply -f monitoring/prometheus-deployment.yaml
kubectl port-forward -n devops-app svc/prometheus 9090:9090
# Visit http://localhost:9090
```

#### 6.2 Deploy Grafana

```bash
kubectl apply -f monitoring/grafana-deployment.yaml
kubectl port-forward -n devops-app svc/grafana 3000:3000
# Visit http://localhost:3000
# Username: admin
# Password: admin (change on first login)
```

#### 6.3 Configure Grafana

```
1. Add Data Source → Prometheus
   URL: http://prometheus:9090
   
2. Import Dashboard → Kubernetes Cluster Monitoring (ID: 7249)

3. Create custom dashboard for your app metrics
```

## 📝 Jenkinsfile Explanation

The Jenkinsfile follows declarative pipeline syntax with stages:

1. **Checkout**: Clone repository
2. **Build**: Build Docker image
3. **Test**: Run basic tests
4. **Push**: Push image to registry
5. **Deploy to Dev**: Deploy to dev namespace
6. **Deploy to Prod**: Manual approval, deploy to prod
7. **Health Check**: Verify deployment

## 🐳 Docker Details

### Dockerfile Strategy

- **Base Image**: nginx:alpine (lightweight, ~150MB)
- **Multi-stage**: Not needed for static site, but included structure for scalability
- **Healthcheck**: Included for Kubernetes liveness/readiness probes
- **Port**: 80 (HTTP)

### Docker Compose (Local Development)

```bash
docker-compose -f docker/docker-compose.yml up -d
docker-compose -f docker/docker-compose.yml down
```

## ☸️ Kubernetes Deployment

### Components Created

1. **Namespace**: devops-app (isolation)
2. **Deployment**: 3 replicas by default
3. **Service**: ClusterIP (internal) + LoadBalancer (external)
4. **ConfigMap**: Environment configuration
5. **MySQL StatefulSet**: Persistent database (optional)
6. **Ingress**: External access with SSL ready

### Scaling

```bash
# Scale deployment
kubectl scale deployment/devops-website -n devops-app --replicas=5

# Auto-scaling (requires metrics-server)
kubectl autoscale deployment devops-website -n devops-app \
  --min=3 --max=10 --cpu-percent=80
```

### Update Strategy

```bash
# Rolling update (default)
kubectl set image deployment/devops-website \
  devops-website=yourusername/devops-website:2.0.0 \
  -n devops-app

# Check rollout status
kubectl rollout status deployment/devops-website -n devops-app

# Rollback if needed
kubectl rollout undo deployment/devops-website -n devops-app
```

## 📊 Monitoring & Metrics

### Prometheus Metrics

- Container metrics (CPU, Memory)
- Pod metrics
- Custom application metrics
- Node metrics

### Grafana Dashboards

- Kubernetes cluster overview
- Pod resource usage
- Deployment status
- Application performance

### Available Queries

```
# CPU Usage
rate(container_cpu_usage_seconds_total[5m])

# Memory Usage
container_memory_working_set_bytes

# Pod Count
count(kube_pod_info{namespace="devops-app"})

# Request Rate
rate(http_requests_total[5m])
```

## 🔒 Security Best Practices Implemented

1. **Container Security**
   - Non-root user (nginx)
   - Read-only filesystem
   - Resource limits

2. **Kubernetes Security**
   - Namespace isolation
   - Network policies (can be added)
   - RBAC ready

3. **Registry Security**
   - Image scanning
   - Private registries
   - Tag versioning

## 🧪 Testing

### Local Testing

```bash
# Build locally
docker build -t devops-website:test -f docker/Dockerfile .

# Run container
docker run -p 8080:80 devops-website:test

# Test endpoint
curl http://localhost:8080
```

### Kubernetes Testing

```bash
# Port forward to test
kubectl port-forward -n devops-app svc/devops-website 8080:80

# Test
curl http://localhost:8080
```

## 📈 CI/CD Pipeline Flow

```
1. Developer commits code → Pushes to GitHub/GitLab
2. Jenkins detects change (webhook) → Triggers job
3. Pipeline stages:
   - Checkout code
   - Build Docker image
   - Run tests (security scan, etc.)
   - Push to registry
   - Deploy to staging/dev
   - Run integration tests
   - Manual approval for production
   - Deploy to production
   - Run health checks
   - Notify team
```

## 🔄 Git Workflow

### Branch Strategy

```bash
# Main branch for production
git checkout main

# Create feature branch
git checkout -b feature/new-feature

# Make changes and commit
git add .
git commit -m "feat: add new feature"

# Push to remote
git push origin feature/new-feature

# Create Pull Request on GitHub
# After review and merge to main, Jenkins automatically deploys
```

## 📚 Learning Outcomes

After completing this project, you'll understand:

✅ Docker containerization and image optimization
✅ Kubernetes deployment, scaling, and rolling updates
✅ Jenkins CI/CD pipeline creation
✅ Container registry management
✅ Application monitoring with Prometheus & Grafana
✅ Database integration in Kubernetes
✅ Git workflows and best practices
✅ Infrastructure as Code principles

## 🐛 Troubleshooting

### Pod not starting

```bash
kubectl describe pod <pod-name> -n devops-app
kubectl logs <pod-name> -n devops-app
```

### Image pull errors

```bash
# Check docker credentials
kubectl get secrets -n devops-app
kubectl create secret docker-registry regcred \
  --docker-server=docker.io \
  --docker-username=yourusername \
  --docker-password=yourtoken \
  -n devops-app
```

### Jenkins not triggering

```bash
# Verify webhook in GitHub/GitLab
# Check Jenkins logs: Manage Jenkins → System Log
# Verify Jenkinsfile path and syntax
```

### Prometheus not scraping

```bash
kubectl logs -n devops-app deployment/prometheus
# Check prometheus.yml configuration
# Verify service discovery
```

## 📞 Support Resources

- [Docker Docs](https://docs.docker.com/)
- [Kubernetes Docs](https://kubernetes.io/docs/)
- [Jenkins Docs](https://www.jenkins.io/doc/)
- [Prometheus Docs](https://prometheus.io/docs/)
- [Grafana Docs](https://grafana.com/docs/)

## 📄 License

This project is open source and available under MIT License.

## 🤝 Contributing

Feel free to fork, modify, and improve this project for your learning!

---

**Happy DevOps Learning! 🚀**
