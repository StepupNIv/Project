# Quick Start Guide

Get your DevOps project running in 5 minutes!

## 🚀 Fastest Way to Get Started

### Option 1: Using Docker Compose (Easiest)

```bash
# Clone repository
git clone https://github.com/yourusername/devops-website-project.git
cd devops-website-project

# Start everything
docker-compose -f docker/docker-compose.yml up -d

# Access services
# Website: http://localhost:8080
# Prometheus: http://localhost:9090
# Grafana: http://localhost:3000 (admin/admin123)
# MySQL: localhost:3306 (devops_user/devops_pass123)
```

### Option 2: Using Make (Most Convenient)

```bash
# Install make (if not already installed)
# macOS: brew install make
# Ubuntu: sudo apt-get install make

# View all available commands
make help

# Build and test locally
make build
make test-docker

# Start Docker Compose environment
make docker-compose-up

# View logs
make docker-compose-logs

# Stop everything
make docker-compose-down
```

### Option 3: Using Kubernetes (Production-like)

```bash
# Prerequisites:
# - Kubernetes cluster running (minikube, EKS, GKE, AKS, etc.)
# - kubectl configured
# - Docker image built and pushed to registry

# Pre-deployment checks
make k8s-check

# Deploy
make k8s-deploy

# View status
make k8s-status

# Access application
make k8s-port-forward
# Then visit http://localhost:8080
```

### Option 4: Using Helm (Most Flexible)

```bash
# Lint chart
make helm-lint

# Install
make helm-install

# Upgrade
make helm-upgrade

# Check status
make helm-status

# Uninstall
make helm-uninstall
```

---

## 📋 Step-by-Step Setup

### Step 1: Prerequisites

```bash
# Check if you have required tools
docker --version
docker-compose --version
kubectl version --client
helm version

# If missing, install them:
# - Docker: https://docs.docker.com/get-docker/
# - Docker Compose: https://docs.docker.com/compose/install/
# - kubectl: https://kubernetes.io/docs/tasks/tools/
# - Helm: https://helm.sh/docs/intro/install/
```

### Step 2: Clone Repository

```bash
git clone https://github.com/yourusername/devops-website-project.git
cd devops-website-project

# List available files
ls -la
```

### Step 3: Build Docker Image

```bash
# Build locally
docker build -t devops-website:1.0.0 -f docker/Dockerfile .

# Verify build
docker images | grep devops-website
```

### Step 4: Run Locally

```bash
# Option A: Single container
docker run -d -p 8080:8080 --name devops-website devops-website:1.0.0

# Option B: Full stack with Compose
docker-compose -f docker/docker-compose.yml up -d

# Test application
curl http://localhost:8080
```

### Step 5: Deploy to Kubernetes

```bash
# Create namespace
kubectl create namespace devops-app

# Deploy application
kubectl apply -f kubernetes/namespace.yaml
kubectl apply -f kubernetes/configmap.yaml
kubectl apply -f kubernetes/deployment.yaml
kubectl apply -f kubernetes/service.yaml

# Check deployment
kubectl get pods -n devops-app
kubectl get svc -n devops-app

# Port forward to test
kubectl port-forward -n devops-app svc/devops-website 8080:80
curl http://localhost:8080
```

---

## 🔧 Common Tasks

### Build and Push Docker Image

```bash
# Build
docker build -t devops-website:1.0.0 -f docker/Dockerfile .

# Tag for registry
docker tag devops-website:1.0.0 yourusername/devops-website:1.0.0

# Push to Docker Hub
docker login
docker push yourusername/devops-website:1.0.0
```

### Deploy to Kubernetes

```bash
# Using kubectl
kubectl apply -f kubernetes/

# Using Helm
helm install devops-website helm/devops-website \
  --namespace devops-app \
  --create-namespace

# Using Make
make k8s-deploy
```

### View Logs

```bash
# Docker
docker logs -f devops-website

# Docker Compose
docker-compose logs -f

# Kubernetes
kubectl logs -f -n devops-app deployment/devops-website
```

### Scale Application

```bash
# Kubernetes - manual
kubectl scale deployment/devops-website --replicas=5 -n devops-app

# Kubernetes - auto
kubectl autoscale deployment/devops-website \
  --min=3 --max=10 --cpu-percent=80 -n devops-app

# Helm
helm upgrade devops-website helm/devops-website \
  --set replicaCount=5
```

### Update Deployment

```bash
# Kubernetes
kubectl set image deployment/devops-website \
  devops-website=yourusername/devops-website:2.0.0 \
  -n devops-app

# Helm
helm upgrade devops-website helm/devops-website \
  --set image.tag=2.0.0
```

### Rollback Deployment

```bash
# Kubernetes
kubectl rollout undo deployment/devops-website -n devops-app

# Helm
helm rollback devops-website -n devops-app
```

---

## 📊 Access Services

### Local Development (Docker Compose)

| Service | URL | Credentials |
|---------|-----|-------------|
| Website | http://localhost:8080 | - |
| Prometheus | http://localhost:9090 | - |
| Grafana | http://localhost:3000 | admin/admin123 |
| MySQL | localhost:3306 | devops_user/devops_pass123 |

### Kubernetes

```bash
# Website
kubectl port-forward -n devops-app svc/devops-website 8080:80
# Visit http://localhost:8080

# Prometheus
kubectl port-forward -n devops-app svc/prometheus 9090:9090
# Visit http://localhost:9090

# Grafana
kubectl port-forward -n devops-app svc/grafana 3000:3000
# Visit http://localhost:3000
```

---

## 🧪 Testing

### Health Check

```bash
# Local
curl http://localhost:8080/api/health

# Kubernetes
kubectl port-forward -n devops-app svc/devops-website 8080:80
curl http://localhost:8080/api/health
```

### Load Testing

```bash
# Run load tests
bash scripts/load-test.sh http://localhost:8080 10 60 300

# Or use make
make load-test
```

### Run Tests

```bash
# Docker
make test-docker

# Kubernetes
make test-k8s
```

---

## 📈 Monitoring

### Access Prometheus

```bash
kubectl port-forward -n devops-app svc/prometheus 9090:9090
# Visit http://localhost:9090
# Try query: up
```

### Access Grafana

```bash
kubectl port-forward -n devops-app svc/grafana 3000:3000
# Visit http://localhost:3000
# Username: admin
# Password: admin123

# Add Prometheus data source
# Configuration → Data Sources → Prometheus → http://prometheus:9090
```

### View Metrics

```bash
# CPU Usage
kubectl top pods -n devops-app

# Node Resources
kubectl top nodes

# Pod Metrics
kubectl exec -it <pod-name> -n devops-app -- cat /proc/stat
```

---

## 🔍 Troubleshooting

### Pod Not Starting?

```bash
# Check status
kubectl describe pod <pod-name> -n devops-app

# View logs
kubectl logs <pod-name> -n devops-app

# Check events
kubectl get events -n devops-app
```

### Can't Connect to Service?

```bash
# Test connectivity
kubectl run -it --rm debug --image=busybox -- wget -O- http://devops-website

# Check endpoints
kubectl get endpoints -n devops-app

# Test DNS
kubectl run -it --rm debug --image=busybox -- nslookup devops-website
```

### Image Pull Failed?

```bash
# Check image
docker images | grep devops-website

# Push to registry
docker push yourusername/devops-website:latest

# Update Kubernetes image
kubectl set image deployment/devops-website \
  devops-website=yourusername/devops-website:latest \
  -n devops-app
```

---

## 🧹 Cleanup

### Stop Docker Compose

```bash
docker-compose -f docker/docker-compose.yml down

# Or
make docker-compose-down
```

### Delete Kubernetes Deployment

```bash
kubectl delete namespace devops-app

# Or
make k8s-delete
```

### Clean Docker

```bash
docker system prune -f

# Or
make clean
```

---

## 📚 More Information

- **Complete README**: See [README.md](../README.md)
- **Jenkins Setup**: See [docs/JENKINS_SETUP.md](docs/JENKINS_SETUP.md)
- **Deployment Guide**: See [docs/DEPLOYMENT_GUIDE.md](docs/DEPLOYMENT_GUIDE.md)
- **Troubleshooting**: See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

---

## 🚀 Next Steps

1. ✅ Get services running (you've done this!)
2. 📝 Customize configuration for your environment
3. 🔧 Setup Jenkins CI/CD pipeline
4. 📊 Configure monitoring and alerting
5. 🔐 Implement security policies
6. 🧪 Run load tests
7. 📚 Document your setup

---

## 💡 Tips

- Use `make help` to see all available commands
- Check logs frequently: `make logs-app`
- Monitor resources: `make monitor-prometheus`
- Always run pre-deployment checks: `make k8s-check`
- Keep backups: `make db-backup`

---

## 🆘 Getting Help

### Useful Commands

```bash
# Show all pods
kubectl get pods -A

# Show all services
kubectl get svc -A

# Show all deployments
kubectl get deployment -A

# Get detailed info
kubectl describe <resource> <name> -n devops-app

# Check recent logs
kubectl logs -f <pod-name> -n devops-app
```

### Documentation

- Kubernetes: https://kubernetes.io/docs/
- Docker: https://docs.docker.com/
- Helm: https://helm.sh/docs/
- Jenkins: https://jenkins.io/doc/
- Prometheus: https://prometheus.io/docs/

---

**You're all set! Start building! 🎉**
